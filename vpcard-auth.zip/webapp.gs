/**
 * webapp.gs  —  ตัวรับข้อมูลจากแอปบัตร แล้วแยกลงแผ่นงานตาม "ประเภทผู้ขอ"
 * (ฉบับมีระบบล็อกอิน: ตรวจสิทธิ์ด้วย token ของผู้ใช้ผ่าน au_ok ในไฟล์ Auth)
 */

// ====== ตั้งค่า ======
const SPREADSHEET_ID = '1F6mfoY5O2LEewSiXWKg5mPbPKvSWdJjvfpyA1SAw43U'; // รหัสชีท (ส่วนกลางของลิงก์ระหว่าง /d/ กับ /edit)

// รหัสประเภท (ที่แอปส่งมา)  ->  ชื่อแผ่นงาน (ต้องสะกดตรงกับชื่อแท็บด้านล่างชีท)
const TABS = {
  shop:    'ร้านค้า/ขายสินค้า',
  student: 'นักเรียนหลักสูตร',
  build:   'โครงการก่อสร้าง',
  family:  'ครอบครัวกำลังพล'
};

// ชื่อเก่าที่ยอมรับ (กันพลาดถ้ายังไม่ได้เปลี่ยนชื่อแท็บ Untitled)
const LEGACY = { shop: ['Untitled'] };

// ชื่อประเภทตัวอักษร (คอลัมน์ I) -> รหัส  ใช้สำรองกรณีแอปรุ่นเก่าไม่ได้ส่ง cat มา
const LABEL2CAT = {
  'ร้านค้า / ขายสินค้า': 'shop',
  'นักเรียนหลักสูตร': 'student',
  'โครงการก่อสร้าง': 'build',
  'ครอบครัวกำลังพล': 'family'
};

// หัวตาราง (ใช้เฉพาะตอนสร้างแผ่นงานใหม่ที่ยังไม่มี)
const HEAD = ['ลำดับ','วันที่-เวลาบันทึก','ประเภทบัตร','เลขที่บัตร','ชื่อ-นามสกุล','เลขบัตรประชาชน',
  'โทรศัพท์','ที่อยู่','ประเภทผู้ขอ','ร้านค้า/สินค้า/หลักสูตร/โครงการ','ประเภทยานพาหนะ',
  'รุ่นรถ','สีรถ','ทะเบียนรถ','จังหวัด','ใช้ได้ถึง'];
// ======================

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

// หาแผ่นงานตามรหัสประเภท ถ้าไม่เจอให้สร้างใหม่พร้อมหัวตาราง
function getSheet_(ss, cat) {
  let sh = ss.getSheetByName(TABS[cat]);
  if (!sh) {
    for (const n of (LEGACY[cat] || [])) { sh = ss.getSheetByName(n); if (sh) break; }
  }
  if (!sh) {
    sh = ss.insertSheet(TABS[cat]);
    sh.getRange(1, 1, 1, HEAD.length).setValues([HEAD]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

// GET: ส่งเลข gid ของทุกแผ่นงานให้แอปทำปุ่ม "เด้งไปแผ่นงานนั้น" (ต้องมี token ผู้ใช้)
function doGet(e) {
  if (!e || !e.parameter || !au_ok(e.parameter.token)) return json_({ ok: false, error: 'UNAUTHORIZED' });
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const gid = {};
  Object.keys(TABS).forEach(k => { gid[k] = getSheet_(ss, k).getSheetId(); });
  return json_({ ok: true, gid: gid });
}

// POST: รับแถวข้อมูล แล้วต่อท้ายลงแผ่นงานที่ตรงกับประเภท
function doPost(e) {
  // 1) คำสั่งล็อกอิน/จัดการผู้ใช้ (login, me, listUsers, ...) -> ให้ Auth จัดการ
  const a = au_tryHandle(e); if (a) return a;

  // 2) ที่เหลือคือการบันทึกบัตร: ตรวจ token ผู้ใช้ "ก่อน" เข้าคิวล็อก
  let req;
  try { req = JSON.parse(e.postData.contents); }
  catch (x) { return json_({ ok: false, error: 'bad request' }); }
  if (!au_ok(req.token)) return json_({ ok: false, error: 'UNAUTHORIZED' });

  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);                       // กันสองคนกดบันทึกพร้อมกันแล้วแถวทับกัน

    const row = req.row;
    if (!Array.isArray(row)) return json_({ ok: false, error: 'no row' });

    const cat = TABS[req.cat] ? req.cat : (LABEL2CAT[row[8]] || 'shop');
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    const sh = getSheet_(ss, cat);

    // ลำดับ = จำนวนแถวข้อมูลในแผ่นงานนั้น + 1  (แถว 1 คือหัวตาราง)
    const last = Math.max(sh.getLastRow(), 1);
    row[0] = last;                              // แถวใหม่จะอยู่แถวที่ last+1 -> ลำดับ = last

    // ตั้งเป็นข้อความทั้งแถว กัน Sheets แปลงเลข 0 นำหน้าเบอร์โทร/เลขบัตรหาย
    const range = sh.getRange(last + 1, 1, 1, row.length);
    range.setNumberFormat('@');
    range.setValues([row]);

    return json_({ ok: true, sheet: TABS[cat], gid: sh.getSheetId(), seq: last });
  } catch (err) {
    console.error(err);
    return json_({ ok: false, error: 'SERVER_ERROR' });
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}
