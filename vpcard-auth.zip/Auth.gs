/** Auth.gs — ระบบล็อกอิน (เพิ่มเป็นไฟล์ใหม่ในโปรเจกต์เดิม ชื่อฟังก์ชันขึ้นต้น au_ จึงไม่ชนกับโค้ดเดิม)
 *  ใช้ SPREADSHEET_ID จากไฟล์ รหัส.gs เดิม และสร้างแผ่นงานชื่อ Users ในชีทเดียวกัน */
const AU_SHEET = 'Users';
const AU_HEAD = ['name','unit','code','email','role','status','created','salt','hash'];
const AU_TTL = 6 * 60 * 60;            // วินาที (สูงสุดของ CacheService = 6 ชม.)
const AU_MAX_FAILS = 5, AU_LOCK = 300; // ผิด 5 ครั้ง ล็อก 5 นาที
const AU_ACTIONS = ['login','logout','me','listUsers','createUser','setStatus'];

/** ใส่เป็นบรรทัดแรกใน doPost เดิม:  const a = au_tryHandle(e); if (a) return a; */
function au_tryHandle(e) {
  let req;
  try { req = JSON.parse(e.postData.contents); } catch (x) { return null; }
  if (!req || AU_ACTIONS.indexOf(req.action) < 0) return null;   // ไม่ใช่คำสั่งล็อกอิน -> ปล่อยให้โค้ดเดิมทำงานต่อ
  let res;
  try { res = au_route(req); }
  catch (err) {
    const m = String(err.message);
    if (!/^[A-Z_]+$/.test(m)) console.error(err);
    res = { ok: false, error: /^[A-Z_]+$/.test(m) ? m : 'SERVER_ERROR' };
  }
  return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
}

function au_route(r) {
  switch (r.action) {
    case 'login':  return au_login(r.email, r.password);
    case 'logout': CacheService.getScriptCache().remove('t_' + r.token); return { ok: true };
    case 'me':     return { ok: true, user: au_pub(au_auth(r.token)) };
    case 'listUsers':  au_auth(r.token, true); return { ok: true, users: au_all().map(au_pub) };
    case 'createUser': au_auth(r.token, true); return au_create(r);
    case 'setStatus':  return au_setStatus(au_auth(r.token, true), r.email, r.status);
  }
}

/* ---------- แผ่นงาน Users ---------- */
function au_sheet() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  let s = ss.getSheetByName(AU_SHEET);
  if (!s) { s = ss.insertSheet(AU_SHEET); s.appendRow(AU_HEAD); s.setFrozenRows(1); }
  return s;
}
function au_all() {
  const v = au_sheet().getDataRange().getValues(); v.shift();
  return v.map((row, i) => { const o = { _row: i + 2 }; AU_HEAD.forEach((h, j) => o[h] = row[j]); return o; });
}
function au_find(email) {
  email = String(email || '').trim().toLowerCase();
  return au_all().find(u => String(u.email).toLowerCase() === email) || null;
}
function au_pub(u) { return { name: u.name, unit: u.unit, code: u.code, email: u.email, role: u.role, status: u.status, created: u.created }; }
function au_clean(s) { s = String(s || '').trim(); return /^[=+\-@]/.test(s) ? "'" + s : s; }

function au_hash(pw, salt) {
  let h = salt + pw;
  for (let i = 0; i < 1000; i++) {
    h = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, h + salt, Utilities.Charset.UTF_8)
      .map(b => ('0' + (b & 0xff).toString(16)).slice(-2)).join('');
  }
  return h;
}

/* ---------- ล็อกอิน / token ---------- */
function au_login(email, pw) {
  email = String(email || '').trim().toLowerCase();
  const c = CacheService.getScriptCache(), fk = 'f_' + email;
  if ((+c.get(fk) || 0) >= AU_MAX_FAILS) throw new Error('TOO_MANY_ATTEMPTS');
  const u = au_find(email);
  if (!u || au_hash(String(pw || ''), u.salt) !== u.hash) {
    c.put(fk, String((+c.get(fk) || 0) + 1), AU_LOCK);
    throw new Error('BAD_CREDENTIALS');
  }
  if (u.status !== 'Active') throw new Error('BLOCKED');
  c.remove(fk);
  const token = Utilities.getUuid() + Utilities.getUuid();
  c.put('t_' + token, email, AU_TTL);
  return { ok: true, token: token, user: au_pub(u) };
}
/** ตรวจ token (ใช้ในฟังก์ชันอื่นด้วย) — ถ้าไม่ผ่านจะ throw UNAUTHORIZED; คืน user ถ้าผ่าน */
function au_auth(token, adminOnly) {
  const email = token && CacheService.getScriptCache().get('t_' + token);
  if (!email) throw new Error('UNAUTHORIZED');
  const u = au_find(email);
  if (!u || u.status !== 'Active') throw new Error('UNAUTHORIZED');
  if (adminOnly && u.role !== 'Admin') throw new Error('FORBIDDEN');
  return u;
}

/* ---------- จัดการผู้ใช้ (Admin) ---------- */
function au_create(r) {
  const email = String(r.email || '').trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error('BAD_EMAIL');
  if (String(r.password || '').length < 8) throw new Error('WEAK_PASSWORD');
  if (!r.name || !r.unit || !r.code) throw new Error('MISSING_FIELDS');
  const lock = LockService.getScriptLock(); lock.waitLock(10000);
  try {
    if (au_find(email)) throw new Error('EMAIL_EXISTS');
    const salt = Utilities.getUuid();
    au_sheet().appendRow([au_clean(r.name), au_clean(r.unit), au_clean(r.code), email,
      r.role === 'Admin' ? 'Admin' : 'Data Entry', 'Active', Date.now(), salt, au_hash(String(r.password), salt)]);
  } finally { lock.releaseLock(); }
  return { ok: true };
}
function au_setStatus(admin, email, status) {
  const u = au_find(email);
  if (!u) throw new Error('NOT_FOUND');
  if (u.email === admin.email) throw new Error('CANNOT_BLOCK_SELF');
  au_sheet().getRange(u._row, AU_HEAD.indexOf('status') + 1).setValue(status === 'Active' ? 'Active' : 'Blocked');
  return { ok: true };
}

/* ---------- รันครั้งเดียว: สร้างแอดมินคนแรก ---------- */
function createFirstAdmin() {
  const EMAIL = 'admin@example.com';          // <-- แก้เป็นอีเมลของคุณ
  const PASS  = 'ตั้งรหัสผ่านอย่างน้อย8ตัว';   // <-- แก้ แล้วลบทิ้งหลังรันเสร็จ
  au_create({ name: 'ผู้ดูแลระบบ', unit: 'ส่วนกลาง', code: 'ADMIN', email: EMAIL, password: PASS, role: 'Admin' });
}

/** ใช้แทนการเช็ก TOKEN ตายตัวเดิม: คืน true ถ้า token ของผู้ใช้ถูกต้องและยัง Active */
function au_ok(token) {
  try { au_auth(token); return true; } catch (e) { return false; }
}
